const { Client, IntentBitField } = require('discord.js');
const client = new Client ({
  Intents: [
    IntentBitField.Flags.Guilds,
    IntentBitField.Flags.GuildMembers,
    IntentBitField.Flags.GuildMessages,
    IntentBitField.Flags.MessageContent,
  ], 
});

client.login("");
